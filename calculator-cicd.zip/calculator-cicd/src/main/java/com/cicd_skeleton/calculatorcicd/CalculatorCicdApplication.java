package com.cicd_skeleton.calculatorcicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorCicdApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorCicdApplication.class, args);
	}

}

